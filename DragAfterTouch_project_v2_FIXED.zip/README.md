# DragAfterTouch AndroidIDE v4

휴대폰 AndroidIDE에서 빌드하기 쉽게 Kotlin 대신 Java를 사용하고,
Groovy Gradle 파일을 사용한 단순 프로젝트입니다.

## 빌드

AndroidIDE에서 프로젝트 루트( settings.gradle 이 있는 폴더)를 열고
Gradle Sync 후 Assemble Debug / Build APK를 실행합니다.

APK:
app/build/outputs/apk/debug/app-debug.apk

## 동작

ACTION_DOWN / MOVE를 짧은 합성 제스처로 재생하고,
ACTION_UP에서 마지막 세그먼트를 요청한 뒤 결과 콜백을 기다리지 않고
설정된 좌표에 탭을 요청합니다.

## Android 제한

AccessibilityService의 MotionEvent 처리와 dispatchGesture는
원본 하드웨어 입력의 100% 투명한 passthrough가 아닙니다.
또한 dispatchGesture는 다른 진행 중 제스처를 취소할 수 있으므로
게임마다 결과가 다를 수 있습니다.

이 프로젝트는 "UP 후 탭 지연 최소화"를 우선한 실험 버전입니다.
