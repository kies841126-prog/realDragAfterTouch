package com.example.dragaftertouch;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.widget.Toast;

public class DragTouchService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean active = false;
    private float lastX, lastY;
    private long downTime, lastTime;

    @Override public void onServiceConnected() {
        super.onServiceConnected();

        AccessibilityServiceInfo i = getServiceInfo();
        i.flags |= AccessibilityServiceInfo.FLAG_SEND_MOTION_EVENTS;
        i.setMotionEventSources(InputDevice.SOURCE_TOUCHSCREEN);
        setServiceInfo(i);

        Toast.makeText(this,"드래그 후 즉시 터치 ON",Toast.LENGTH_SHORT).show();
    }

    @Override public void onMotionEvent(MotionEvent e) {
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                active = true;
                downTime = e.getEventTime();
                lastTime = downTime;
                lastX = e.getRawX();
                lastY = e.getRawY();
                relaySegment(lastX,lastY,lastX,lastY,1);
                break;

            case MotionEvent.ACTION_MOVE:
                if (!active) return;
                float nx=e.getRawX(), ny=e.getRawY();
                long dur=Math.max(1,e.getEventTime()-lastTime);
                relaySegment(lastX,lastY,nx,ny,dur);
                lastX=nx; lastY=ny; lastTime=e.getEventTime();
                break;

            case MotionEvent.ACTION_UP:
                if (!active) return;
                active=false;
                float ux=e.getRawX(), uy=e.getRawY();
                long ud=Math.max(1,e.getEventTime()-lastTime);

                // Finish the last tiny segment, then request the target tap.
                // We deliberately do not wait for GestureResultCallback.
                relaySegment(lastX,lastY,ux,uy,ud);
                lastX=ux; lastY=uy;
                scheduleTap();
                break;

            case MotionEvent.ACTION_CANCEL:
                active=false;
                break;
        }
    }

    private void relaySegment(float x1,float y1,float x2,float y2,long duration) {
        Path path=new Path();
        path.moveTo(x1,y1);
        path.lineTo(x2,y2);

        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path,0,duration);

        dispatchGesture(
            new GestureDescription.Builder().addStroke(stroke).build(),
            null,null
        );
    }

    private void scheduleTap() {
        android.content.SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);
        float x=p.getInt("x",850);
        float y=p.getInt("y",1200);
        long delay=Math.max(0,p.getLong("delay",0));

        handler.postDelayed(() -> {
            Path path=new Path();
            path.moveTo(x,y);

            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path,0,10);

            dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                null,null
            );
        },delay);
    }

    @Override public void onInterrupt() { active=false; }

    @Override public void onDestroy() {
        active=false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
