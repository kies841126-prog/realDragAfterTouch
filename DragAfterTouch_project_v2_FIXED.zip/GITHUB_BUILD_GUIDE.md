# 휴대폰만으로 APK 만들기

1. GitHub에서 새 repository를 만듭니다.
2. 이 프로젝트의 압축을 풀고 **파일/폴더를 그대로** repository에 업로드합니다.
3. `main` 브랜치에 업로드가 끝나면 GitHub Actions가 자동으로 빌드됩니다.
4. 저장소의 **Actions → Build APK**에서 실행 결과를 엽니다.
5. 완료된 workflow의 **Artifacts → DragAfterTouch-debug-apk**를 다운로드합니다.
6. ZIP을 풀면 `app-debug.apk`가 나옵니다.
7. APK를 설치합니다.

## 수동 실행

Actions 탭에서 `Build APK` workflow를 선택한 뒤 `Run workflow`를 누를 수도 있습니다.

## 주의

- GitHub Actions가 프로젝트를 서버에서 빌드합니다.
- debug APK이므로 설치 시 Android가 보안 경고를 표시할 수 있습니다.
- APK는 현재 프로젝트의 실험용 접근성 서비스 버전입니다.
- Android의 입력 보안 때문에 실제 하드웨어 터치를 다른 앱에 100% 투명하게 통과시키는 것은 보장되지 않습니다.
