package com.example.dragaftertouch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        android.content.SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32,32,32,32);

        TextView title = new TextView(this);
        title.setText("드래그 후 즉시 터치");
        title.setTextSize(24);
        box.addView(title);

        TextView info = new TextView(this);
        info.setText("\nAndroidIDE용 v4\n손가락 UP 직후 지정 좌표에 탭을 요청합니다.\n" +
                "Android 보안 구조상 원본 터치 100% 통과가 아니라 접근성 합성 터치 방식입니다.\n");
        box.addView(info);

        EditText x = field(box, "자동 터치 X", String.valueOf(p.getInt("x",850)));
        EditText y = field(box, "자동 터치 Y", String.valueOf(p.getInt("y",1200)));
        EditText d = field(box, "UP 후 지연(ms)", String.valueOf(p.getLong("delay",0)));

        Button save = new Button(this);
        save.setText("설정 저장");
        save.setOnClickListener(v -> {
            p.edit()
             .putInt("x", parse(x,850))
             .putInt("y", parse(y,1200))
             .putLong("delay", parseLong(d,0))
             .apply();
            Toast.makeText(this,"저장 완료",Toast.LENGTH_SHORT).show();
        });
        box.addView(save);

        Button access = new Button(this);
        access.setText("접근성 설정 열기");
        access.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(access);

        TextView usage = new TextView(this);
        usage.setText("\n사용법\n1. 좌표 입력\n2. 저장\n3. 접근성 서비스 켜기\n4. 게임에서 드래그\n5. 손을 떼면 자동 터치\n\n권장 지연: 0ms → 게임에서 문제가 있으면 5ms, 10ms 순서로 테스트");
        box.addView(usage);

        setContentView(box);
    }

    private EditText field(LinearLayout box,String label,String value) {
        TextView t = new TextView(this);
        t.setText(label);
        box.addView(t);
        EditText e = new EditText(this);
        e.setText(value);
        e.setInputType(2);
        box.addView(e);
        return e;
    }

    private int parse(EditText e,int fallback) {
        try { return Integer.parseInt(e.getText().toString()); }
        catch(Exception ex) { return fallback; }
    }
    private long parseLong(EditText e,long fallback) {
        try { return Long.parseLong(e.getText().toString()); }
        catch(Exception ex) { return fallback; }
    }
}
